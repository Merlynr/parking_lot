/**
 * Copyright (c) 2014-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

console.warn(
  "The regenerator/runtime module is deprecated; " +
    "please import regenerator-runtime/runtime instead."
);

module.exports = require("regenerator-runtime/runtime");
