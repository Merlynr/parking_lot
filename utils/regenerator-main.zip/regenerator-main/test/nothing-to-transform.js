function asdf() {
  return "no generators or a-s-y-n-c functions to see here";
}
