async function foo() {
  for (let i; i;);
}
